// Função para validar o formulário de login
function validateForm() {
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  if (username.trim() === "" || password.trim() === "") {
      displayErrorMessage("Por favor, preencha todos os campos.");
      return false;
  }

  // Permitir que o formulário seja submetido normalmente
  return true;
}

// Função para exibir mensagem de erro
function displayErrorMessage(message) {
  var errorMessage = document.getElementById("error-message");
  errorMessage.innerHTML = message;
}

// Função para fazer logout (mantenha como está)
function logout() {
  document.cookie = "authToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
  window.location.href = "http://localhost/paginas/public/login";
}
