console.log("Script carregado!"); // Mensagem no console quando o script é carregado.

// Funções existentes (searchJobs e filterJobs) podem permanecer como estão.

// Adiciona um ouvinte de evento ao formulário de adicionar vaga
document.getElementById('addVagaForm').addEventListener('submit', function (e) {
  e.preventDefault(); // Impede o envio normal do formulário

  // Coleta os dados do formulário
  var formData = new FormData(this);

  // Envia os dados para o servidor
  fetch('http://localhost/paginas/public/RecrutamentoController/adicionarVaga', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      alert("Vaga adicionada com sucesso!");
      // Atualiza a página ou faz outras ações necessárias
    } else {
      alert("Erro ao adicionar a vaga.");
    }
  })
  .catch(error => console.error('Erro:', error));
});

// Função para preencher o modal de edição com os dados da vaga
function preencherModalEdicao(id_vag, titulo_vag, end_vag, salario_vag, cargo_vag, desc_vag, req_vag, benef_vag) {
  $("#id_vag_edit").val(id_vag);
  $("#titulo_vag_edit").val(titulo_vag);
  $("#end_vag_edit").val(end_vag);
  $("#salario_vag_edit").val(salario_vag);
  $("#cargo_vag_edit").val(cargo_vag);
  $("#desc_vag_edit").val(desc_vag);
  $("#req_vag_edit").val(req_vag);
  $("#benef_vag_edit").val(benef_vag);
}

$(document).ready(function() {
  // Adicione um ouvinte de evento para abrir o modal de edição ao clicar em "Editar"
  $(".editar-btn").click(function() {
    var id_vag = $(this).data("id_vag");
    var titulo_vag = $(this).data("titulo_vag");
    var end_vag = $(this).data("end_vag");
    var salario_vag = $(this).data("salario_vag");
    var cargo_vag = $(this).data("cargo_vag");
    var desc_vag = $(this).data("desc_vag");
    var req_vag = $(this).data("req_vag");
    var benef_vag = $(this).data("benef_vag");
    
    preencherModalEdicao(id_vag, titulo_vag, end_vag, salario_vag, cargo_vag, desc_vag, req_vag, benef_vag);
    $("#editarVagaModal").modal("show");
  });

  // Adicione um ouvinte de evento para salvar a edição
  $("#btnSalvarEdicao").click(function() {
    // Coleta os dados do modal de edição
    var formData = new FormData($("#editarVagaForm")[0]);

    // Envia os dados para o servidor
    $.ajax({
      type: "POST",
      url: "http://localhost/paginas/public/RecrutamentoController/atualizarVaga",
      data: formData,
      processData: false,
      contentType: false,
      success: function(data) {
        if (data.success) {
          alert("Vaga atualizada com sucesso!");
          $("#editarVagaModal").modal("hide");
          // Atualiza a tabela ou faça outras ações necessárias
        } else {
          alert("Erro ao atualizar a vaga.");
        }
      },
      error: function(error) {
        console.error("Erro:", error);
      }
    });
  });

// Adiciona um ouvinte de evento ao formulário de remover vaga
document.getElementById('removeVagaForm').addEventListener('submit', function (e) {
  e.preventDefault(); // Impede o envio normal do formulário

  var vagaId = document.getElementById('vagaId').value;

  if (confirm('Tem certeza que deseja remover a vaga?')) {
    fetch('http://localhost/paginas/public/RecrutamentoController/removerVaga/' + vagaId, {
      method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert("Vaga removida com sucesso!");
        // Remove a linha da tabela ou atualiza a página
      } else {
        alert("Erro ao remover a vaga.");
      }
    })
    .catch(error => console.error('Erro:', error));
  }
});

// Outras funções podem ser adicionadas conforme necessário
console.log("Script carregado!");


// Adicionar mais eventos conforme necessário para editar e excluir

