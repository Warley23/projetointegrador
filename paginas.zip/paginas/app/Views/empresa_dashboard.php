<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>JobSide - Dashboard</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="/paginas/public/css/stylepagina1.css">
  <!-- Adicione as bibliotecas jQuery e Bootstrap CSS -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 pt-16">
<header class="bg-gradient-to-r from-blue-800 to-black py-4 shadow-md fixed top-0 left-0 w-full z-50">
    <div class="container mx-auto px-4">
      <ul class="flex space-x-4 text-white">
        <li class="nav-item"><a href="http://localhost/paginas/public/#">Início</a></li>
        <li class="nav-item">
          <form id="logout-form" action="http://localhost/paginas/public/logout" method="post">
            <button type="submit" class="btn-primary">Logout</button>
          </form>
        </li>
      </ul>
    </div>
  </header>
  <main class="flex justify-center items-center min-h-screen mt-8">
    <section class="panel bg-white rounded-lg shadow-md p-8 w-full max-w-7xl space-y-6">
      <!-- Seção para Adicionar Nova Vaga -->
      <div class="panel-item">
        <h2 class="text-xl font-bold mb-2">Adicionar Nova Vaga</h2>
        <form action="<?= site_url('RecrutamentoController/adicionarVaga') ?>" method="POST">
          <!-- Campos de adição de vaga aqui -->
          <div class="mb-4">
            <label for="titulo_vag" class="block text-sm font-medium text-gray-700">Título da Vaga</label>
            <input type="text" id="titulo_vag" name="titulo_vag" required class="mt-1 block w-full" placeholder="Título da Vaga">
          </div>

          <div class="mb-4">
            <label for="data_publi_vag" class="block text-sm font-medium text-gray-700">Data de Publicação</label>
            <input type="date" id="data_publi_vag" name="data_publi_vag" class="mt-1 block w-full">
          </div>

          <div class="mb-4">
            <label for="end_vag" class="block text-sm font-medium text-gray-700">Endereço da Vaga</label>
            <input type="text" id="end_vag" name="end_vag" class="mt-1 block w-full" placeholder="Endereço da Vaga">
          </div>

          <div class="mb-4">
            <label for="salario_vag" class="block text-sm font-medium text-gray-700">Salário</label>
            <input type="number" id="salario_vag" name="salario_vag" step="0.01" class="mt-1 block w-full" placeholder="Salário">
          </div>

          <div class="mb-4">
            <label for="cargo_vag" class="block text-sm font-medium text-gray-700">Cargo</label>
            <input type="text" id="cargo_vag" name="cargo_vag" class="mt-1 block w-full" placeholder="Cargo">
          </div>

          <div class="mb-4">
            <label for="desc_vag" class="block text-sm font-medium text-gray-700">Descrição da Vaga</label>
            <textarea id="desc_vag" name="desc_vag" required class="mt-1 block w-full" placeholder="Descrição da Vaga"></textarea>
          </div>

          <div class="mb-4">
            <label for="req_vag" class="block text-sm font-medium text-gray-700">Requisitos da Vaga</label>
            <textarea id="req_vag" name="req_vag" required class="mt-1 block w-full" placeholder="Requisitos da Vaga"></textarea>
          </div>

          <div class="mb-4">
            <label for="benef_vag" class="block text-sm font-medium text-gray-700">Benefícios</label>
            <textarea id="benef_vag" name="benef_vag" class="mt-1 block w-full" placeholder="Benefícios"></textarea>
          </div>

          <input type="hidden" id="id_emp" name="id_emp" value="<!-- ID da Empresa -->">
          <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Adicionar Vaga</button>
        </form>
      </div>

      <!-- Seção de Listagem de Vagas -->
      <div class="panel-item">
        <h2 class="text-xl font-bold mb-2">Lista de Vagas</h2>
        <table class="table">
          <thead>
            <tr>
              <th>ID da Vaga</th>
              <th>Título</th>
              <th>Data de Publicação</th>
              <th>Endereço</th>
              <th>Salário</th>
              <th>Cargo</th>
              <th>Descrição</th>
              <th>Requisitos</th>
              <th>Benefícios</th>
              <th>Ação</th>
            </tr>
          </thead>
          <tbody>
            <?php if (isset($vagas)): ?>
              <?php foreach ($vagas as $vaga): ?>
                <tr>
                  <td><?= $vaga['id_vag'] ?></td>
                  <td><?= $vaga['titulo_vag'] ?></td>
                  <td><?= $vaga['data_publi_vag'] ?></td>
                  <td><?= $vaga['end_vag'] ?></td>
                  <td><?= $vaga['salario_vag'] ?></td>
                  <td><?= $vaga['cargo_vag'] ?></td>
                  <td><?= $vaga['desc_vag'] ?></td>
                  <td><?= $vaga['req_vag'] ?></td>
                  <td><?= $vaga['benef_vag'] ?></td>
                  <td>
                    <!-- Botão "Editar" que abre o modal de edição -->
                    <button class="btn btn-primary editar-btn" data-toggle="modal" data-target="#editarVagaModal" data-id_vag="<?= $vaga['id_vag'] ?>" data-titulo_vag="<?= $vaga['titulo_vag'] ?>" data-end_vag="<?= $vaga['end_vag'] ?>" data-salario_vag="<?= $vaga['salario_vag'] ?>" data-cargo_vag="<?= $vaga['cargo_vag'] ?>" data-desc_vag="<?= $vaga['desc_vag'] ?>" data-req_vag="<?= $vaga['req_vag'] ?>" data-benef_vag="<?= $vaga['benef_vag'] ?>">Editar</button>
                    <a href="<?= site_url('RecrutamentoController/removerVaga/'.$vaga['id_vag']) ?>" onclick="return confirm('Tem certeza que deseja deletar esta vaga?');">Deletar</a>
                    <a href="<?= site_url('RecrutamentoController/visualizarCandidatos/'.$vaga['id_vag']) ?>">Candidatos</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>
  </main>
  <footer class="text-center mt-4">
    <p>&copy; JobSide. Todos os direitos reservados.</p>
  </footer>
  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/fetch-polyfill@0.8.2/fetch.min.js"></script>
  <script src="/paginas/public/pagina2.js"></script>
 <!-- Modal de Edição de Vaga -->
<div class="modal fade" id="editarVagaModal" tabindex="-1" role="dialog" aria-labelledby="editarVagaModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editarVagaModalLabel">Editar Vaga</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Formulário de Edição de Vaga -->
        <form id="editarVagaForm">
          <input type="hidden" id="id_vag_edit" name="id_vag_edit" value="">
          <div class="form-group">
            <label for="titulo_vag_edit">Título da Vaga</label>
            <input type="text" class="form-control" id="titulo_vag_edit" name="titulo_vag_edit" placeholder="Novo Título da Vaga" required>
          </div>
          <div class="form-group">
            <label for="end_vag_edit">Endereço da Vaga</label>
            <input type="text" class="form-control" id="end_vag_edit" name="end_vag_edit" placeholder="Novo Endereço da Vaga">
          </div>
          <div class="form-group">
            <label for="salario_vag_edit">Salário</label>
            <input type="number" class="form-control" id="salario_vag_edit" name="salario_vag_edit" step="0.01" placeholder="Novo Salário" required>
          </div>
          <div class="form-group">
            <label for="cargo_vag_edit">Cargo</label>
            <input type="text" class="form-control" id="cargo_vag_edit" name="cargo_vag_edit" placeholder="Novo Cargo">
          </div>
          <div class="form-group">
            <label for="desc_vag_edit">Descrição da Vaga</label>
            <textarea class="form-control" id="desc_vag_edit" name="desc_vag_edit" rows="4" placeholder="Nova Descrição da Vaga" required></textarea>
          </div>
          <div class="form-group">
            <label for="req_vag_edit">Requisitos da Vaga</label>
            <textarea class="form-control" id="req_vag_edit" name="req_vag_edit" rows="4" placeholder="Novos Requisitos da Vaga" required></textarea>
          </div>
          <div class="form-group">
            <label for="benef_vag_edit">Benefícios</label>
            <textarea class="form-control" id="benef_vag_edit" name="benef_vag_edit" rows="4" placeholder="Novos Benefícios"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
        <button type="button" id="btnSalvarEdicao" class="btn btn-primary">Salvar Alterações</button>
      </div>
    </div>
  </div>
</div>
   
</script>
</body>
</html>