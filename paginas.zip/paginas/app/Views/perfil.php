<!-- application/Views/perfil.php -->

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Perfil</title>
    <link rel="stylesheet" href="/paginas/public/css/stylepagina1.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css">
   
    <!-- Adicione seus estilos e scripts aqui, se necessário -->
</head>
<body>
    <h1>Perfil</h1>

    <!-- Se for um candidato -->
    <?php if ($tipo_usuario === 'candidato'): ?>
        <h2>Dados do Candidato</h2>
        <form action="<?= site_url('PerfilController/editarCandidato') ?>" method="post">
            <!-- Adicione campos específicos para candidato conforme necessário -->
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?= esc($dados['nome_cand']) ?>" required>
            <!-- Adicione mais campos conforme necessário -->
            <button type="submit">Salvar Alterações</button>
        </form>
    <?php endif; ?>

    <!-- Se for uma empresa -->
    <?php if ($tipo_usuario === 'empresa'): ?>
        <h2>Dados da Empresa</h2>
        <form action="<?= site_url('PerfilController/editarEmpresa') ?>" method="post">
            <!-- Adicione campos específicos para empresa conforme necessário -->
            <label for="nome_empresa">Nome da Empresa:</label>
            <input type="text" id="nome_empresa" name="nome_empresa" value="<?= esc($dados['nome_emp']) ?>" required>
            <!-- Adicione mais campos conforme necessário -->
            <button type="submit">Salvar Alterações</button>
        </form>

        <!-- Botão para criar vagas -->
        <a href="<?= site_url('RecrutamentoController/novaVaga') ?>">Criar Vagas</a>
    <?php endif; ?>

    <!-- Adicione mais lógica conforme necessário para outros tipos de usuários -->

</body>
</html>
