<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>JobSide - Dashboard do Candidato</title>
  <link rel="stylesheet" href="/paginas/public/css/stylepagina1.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css">
  <!-- Adicione os estilos necessários aqui -->
</head>
<body class="bg-gray-200">
  <div class="container mx-auto py-8 px-4">
    <!-- Cabeçalho e navegação aqui -->
    <header class="bg-gradient-to-r from-blue-800 to-black py-4 shadow-md fixed top-0 left-0 w-full z-50">
    <div class="container mx-auto px-4">
      <ul class="flex space-x-4 text-white">
        <li class="nav-item"><a href="http://localhost/paginas/public/#">Início</a></li>
        <li class="nav-item">
          <form id="logout-form" action="http://localhost/paginas/public/logout" method="post">
            <button type="submit" class="btn-primary">Logout</button>
          </form>
        </li>
      </ul>
    </div>
  </header>
    <main class="flex justify-center items-center min-h-screen">
      <section class="panel bg-white rounded-lg shadow-md p-8 w-full max-w-7xl space-y-6">
        <!-- Seção de Vagas Disponíveis -->
        <div class="panel-item">
          <h2 class="text-xl font-bold mb-2">Lista de Vagas Disponíveis</h2>
          <!-- Tabela para exibir informações das vagas -->
          <table class="table">
            <thead>
              <tr>
                <th>ID da Vaga</th>
                <th>Título</th>
                <th>Data de Publicação</th>
                <th>Endereço</th>
                <th>Salário</th>
                <th>Cargo</th>
                <th>Descrição</th>
                <th>Requisitos</th>
                <th>Benefícios</th>
                <th>Ação</th>
              </tr>
            </thead>
            <tbody>
              <!-- Loop para exibir informações das vagas -->
              <?php if (isset($vagas)): ?>
                <?php foreach ($vagas as $vaga): ?>
                  <tr>
                    <td><?= $vaga['id_vag'] ?></td>
                    <td><?= $vaga['titulo_vag'] ?></td>
                    <td><?= $vaga['data_publi_vag'] ?></td>
                    <td><?= $vaga['end_vag'] ?></td>
                    <td><?= $vaga['salario_vag'] ?></td>
                    <td><?= $vaga['cargo_vag'] ?></td>
                    <td><?= $vaga['desc_vag'] ?></td>
                    <td><?= $vaga['req_vag'] ?></td>
                    <td><?= $vaga['benef_vag'] ?></td>
                    <td><a href="<?= site_url('RecrutamentoController/candidatura/'.$vaga['id_vag']) ?>">Candidatar-se</a></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>  
            </tbody>
          </table>
        </div>
        <!-- Outras seções da dashboard do candidato podem ser adicionadas aqui -->
      </section>
    </main>
    <!-- Rodapé aqui -->
  </div>
  <!-- Scripts aqui -->
</body>
</html>
