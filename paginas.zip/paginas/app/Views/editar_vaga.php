<!-- application/Views/editar_vaga.php -->

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Vaga</title>
    <link rel="stylesheet" href="/paginas/public/css/stylepagina1.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css">
</head>
<body>
    <h1>Editar Vaga</h1>
    <!-- Formulário para editar vaga -->
    <form action="<?= site_url('RecrutamentoController/atualizarVaga') ?>" method="post">
        <input type="hidden" name="id" value="<?= esc($vaga['id']) ?>">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" value="<?= esc($vaga['titulo']) ?>" required>
        <!-- Adicione mais campos conforme necessário -->
        <button type="submit">Atualizar vaga</button>
    </form>
</body>
</html>
