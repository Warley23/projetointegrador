<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>JobSide - Criar Conta</title>
    <link rel="stylesheet" href="/paginas/public/css/stylepagina1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css">
</head>

<body class="bg-gray-200">
    <header class="bg-gradient-to-r from-blue-800 to-black py-4 shadow-md fixed top-0 left-0 w-full z-50">
        <div class="container mx-auto px-4">
            <ul class="flex space-x-4 text-white">
                <li class="nav-item"><a href="http://localhost/paginas/public/#">Início</a></li>
                <li class="nav-item"><a href="http://localhost/paginas/public/#sobre">Sobre</a></li>
                <li class="nav-item"><a href="http://localhost/paginas/public/#contato">Contato</a></li>
                <li class="nav-item"><a href="http://localhost/paginas/public/login">Login</a></li>
            </ul>
        </div>
    </header>

    <main class="flex justify-center items-center min-h-screen">
        <section class="login-container bg-gray-50 rounded-lg shadow-md p-8 w-96">
            <h2 class="text-2xl font-bold mb-4 text-center">Criar Conta</h2>
            <form action="<?= site_url('criar-conta') ?>" method="POST" class="space-y-4">
                <label for="username" class="block">Usuário:</label>
                <input type="text" id="username" name="username" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                <!-- Escolha entre candidato e empresa -->
                <label for="accountType" class="block">Tipo de Conta:</label>
                <select id="accountType" name="accountType" required class="input w-full bg-gray-100 px-3 py-2 rounded-md" onchange="showFields()">
                    <option value="">Selecione...</option>
                    <option value="candidato">Candidato</option>
                    <option value="empresa">Empresa</option>
                </select>

                <!-- Campos específicos para candidato -->
                <div id="candidatoFields" style="display: none;">
                    <label for="cpf_cand" class="block">CPF:</label>
                    <input type="text" id="cpf_cand" name="cpf_cand" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="nome_cand" class="block">Nome:</label>
                    <input type="text" id="nome_cand" name="nome_cand" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="data_nasc_cand" class="block">Data de Nascimento:</label>
                    <input type="date" id="data_nasc_cand" name="data_nasc_cand" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="tel_cand" class="block">Telefone:</label>
                    <input type="tel" id="tel_cand" name="tel_cand" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="email_cand" class="block">E-mail:</label>
                    <input type="email" id="email_cand" name="email_cand" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="password_hash" class="block">Senha:</label>
                    <input type="password" id="password_hash" name="password_hash" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">
                </div>

                <!-- Campos específicos para empresa -->
                <div id="empresaFields" style="display: none;">
                    <label for="nome_emp" class="block">Nome da Empresa:</label>
                    <input type="text" id="nome_emp" name="nome_emp" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="cnpj_emp" class="block">CNPJ:</label>
                    <input type="text" id="cnpj_emp" name="cnpj_emp" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="email_emp" class="block">E-mail:</label>
                    <input type="email" id="email_emp" name="email_emp" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">

                    <label for="password_hash" class="block">Senha:</label>
                    <input type="password" id="password_hash" name="password_hash" required class="input w-full bg-gray-100 px-3 py-2 rounded-md">
                </div>

                <button type="submit" class="btn-primary text-black">Criar Conta</button>
            </form>
        </section>
    </main>

    <footer class="text-center mt-4">
        <p>&copy; JobSide. Todos os direitos reservados.</p>
    </footer>

    <script>
    
    function showFields() {
    var accountType = document.getElementById("accountType").value;

    var candidatoFields = document.getElementById("candidatoFields");
    var empresaFields = document.getElementById("empresaFields");

    // Desabilita todos os campos
    disableFields(candidatoFields);
    disableFields(empresaFields);

    // Exibe e habilita os campos específicos do tipo selecionado
    if (accountType === "candidato") {
        candidatoFields.style.display = "block";
        enableFields(candidatoFields);
    } else if (accountType === "empresa") {
        empresaFields.style.display = "block";
        enableFields(empresaFields);
    }
}

function disableFields(fieldsContainer) {
    var inputs = fieldsContainer.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; i++) {
        inputs[i].disabled = true;
    }
}

function enableFields(fieldsContainer) {
    var inputs = fieldsContainer.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; i++) {
        inputs[i].disabled = false;
    }
}

    </script>
</body>

</html>
