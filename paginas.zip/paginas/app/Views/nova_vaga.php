<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>JobSide - Dashboard</title>
  <link rel="stylesheet" href="/paginas/public/css/stylepagina1.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@latest/dist/tailwind.min.css">
</head>
<body class="bg-gray-200 pt-16">
  <header class="bg-gradient-to-r from-blue-800 to-black py-4 shadow-md fixed top-0 left-0 w-full z-50">
    <div class="container mx-auto px-4">
      <ul class="flex space-x-4 text-white">
        <li class="nav-item"><a href="http://localhost/paginas/public/#">Início</a></li>
        <li class="nav-item">
          <form id="logout-form" action="http://localhost/paginas/public/logout" method="post">
            <button type="submit" class="btn-primary">Logout</button>
          </form>
        </li>
      </ul>
    </div>
  </header>
  <main class="flex justify-center items-center min-h-screen mt-8">
    <section class="panel bg-white rounded-lg shadow-md p-8 w-full max-w-7xl space-y-6">
 
        <!-- Seção para Adicionar Nova Vaga -->
 <!-- Seção para Adicionar Nova Vaga -->
<div class="panel-item">
  <h2 class="text-xl font-bold mb-2">Adicionar Nova Vaga</h2>
  <form action="<?= site_url('RecrutamentoController/adicionarVaga') ?>" method="POST">
    <div class="mb-4">
      <label for="titulo_vag" class="block text-sm font-medium text-gray-700">Título da Vaga</label>
      <input type="text" id="titulo_vag" name="titulo_vag" required class="mt-1 block w-full" placeholder="Título da Vaga">
    </div>

    <div class="mb-4">
      <label for="data_publi_vag" class="block text-sm font-medium text-gray-700">Data de Publicação</label>
      <input type="date" id="data_publi_vag" name="data_publi_vag" class="mt-1 block w-full">
    </div>

    <div class="mb-4">
      <label for="end_vag" class="block text-sm font-medium text-gray-700">Endereço da Vaga</label>
      <input type="text" id="end_vag" name="end_vag" class="mt-1 block w-full" placeholder="Endereço da Vaga">
    </div>

    <div class="mb-4">
      <label for="salario_vag" class="block text-sm font-medium text-gray-700">Salário</label>
      <input type="number" id="salario_vag" name="salario_vag" step="0.01" class="mt-1 block w-full" placeholder="Salário">
    </div>

    <div class="mb-4">
      <label for="cargo_vag" class="block text-sm font-medium text-gray-700">Cargo</label>
      <input type="text" id="cargo_vag" name="cargo_vag" class="mt-1 block w-full" placeholder="Cargo">
    </div>

    <div class="mb-4">
      <label for="desc_vag" class="block text-sm font-medium text-gray-700">Descrição da Vaga</label>
      <textarea id="desc_vag" name="desc_vag" required class="mt-1 block w-full" placeholder="Descrição da Vaga"></textarea>
    </div>

    <div class="mb-4">
      <label for="req_vag" class="block text-sm font-medium text-gray-700">Requisitos da Vaga</label>
      <textarea id="req_vag" name="req_vag" required class="mt-1 block w-full" placeholder="Requisitos da Vaga"></textarea>
    </div>

    <div class="mb-4">
      <label for="benef_vag" class="block text-sm font-medium text-gray-700">Benefícios</label>
      <textarea id="benef_vag" name="benef_vag" class="mt-1 block w-full" placeholder="Benefícios"></textarea>
    </div>

    <input type="hidden" name="id_emp" value="<!-- ID da Empresa -->">
    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Adicionar Vaga</button>
        </form>
  </form>
</div>


      <!-- Seção de Listagem de Vagas -->
      <div class="panel-item">
  <h2 class="text-xl font-bold mb-2">Lista de Vagas</h2>
  <table class="table">
    <thead>
      <tr>
        <th>ID da Vaga</th>
        <th>Título</th>
        <th>Data de Publicação</th>
        <th>Endereço</th>
        <th>Salário</th>
        <th>Cargo</th>
        <th>Descrição</th>
        <th>Requisitos</th>
        <th>Benefícios</th>
        <th>Ação</th>
      </tr>
    </thead>
    <tbody>
      <?php if (isset($vagas)): ?>
        <?php foreach ($vagas as $vaga): ?>
          <tr>
            <td><?= $vaga['id_vag'] ?></td>
            <td><?= $vaga['titulo_vag'] ?></td>
            <td><?= $vaga['data_publi_vag'] ?></td>
            <td><?= $vaga['end_vag'] ?></td>
            <td><?= $vaga['salario_vag'] ?></td>
            <td><?= $vaga['cargo_vag'] ?></td>
            <td><?= $vaga['desc_vag'] ?></td>
            <td><?= $vaga['req_vag'] ?></td>
            <td><?= $vaga['benef_vag'] ?></td>
            <td>
              <a href="<?= site_url('RecrutamentoController/atualizarVaga/'.$vaga['id_vag']) ?>">Editar</a>
              <a href="<?= site_url('RecrutamentoController/removerVaga/'.$vaga['id_vag']) ?>" onclick="return confirm('Tem certeza que deseja deletar esta vaga?');">Deletar</a>
              <a href="<?= site_url('RecrutamentoController/visualizarCandidatos/'.$vaga['id_vag']) ?>">Candidatos</a>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

    </section>
  </main>
  <footer class="text-center mt-4">
    <p>&copy; JobSide. Todos os direitos reservados.</p>
  </footer>
  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/fetch-polyfill@0.8.2/fetch.min.js"></script>
  <script src="/paginas/public/pagina2.js"></script>
</body>
</html>
