<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    protected $session;
    protected $userModel;

    public function __construct()
    {
        $this->session = \Config\Services::session();
        $this->userModel = new UserModel();
    }

     // Função de login
     public function login()
     {
         if ($this->request->getMethod() == 'post') {
             $username = $this->request->getPost('username');
             $password = $this->request->getPost('password');
     
             // Verificar credenciais para candidato
             $candidatoModel = new \App\Models\CandidatoModel();
             $candidato = $candidatoModel->verifyCredentials($username, $password);
     
             if ($candidato) {
                 $this->session->set('logged_in', TRUE);
                 $this->session->set('user_id', $candidato['id_cand']);
                 $this->session->set('user_type', 'candidato');
                 return redirect()->to('/candidato-dashboard');
             }
     
             // Verificar credenciais para empresa
             $empresaModel = new \App\Models\EmpresaModel();
             $empresa = $empresaModel->verifyCredentials($username, $password);
     
             if ($empresa) {
                 $this->session->set('logged_in', TRUE);
                 $this->session->set('user_id', $empresa['id_emp']);
                 $this->session->set('user_type', 'empresa');
                 return redirect()->to('/empresa-dashboard');
             }
     
             // Credenciais inválidas
             $data['error_message'] = 'Credenciais inválidas!';
             return view('login', $data);
         }
     
         return view('login');
     }
     
      // Função de logout
      public function logout()
      {
          $this->session->destroy(); // Encerrar a sessão
          return redirect()->to('/login'); // Redirecionar para a página de login
      }
      

    public function criarConta()
    {
        if ($this->request->getMethod() == 'post') {
            // Obter dados do formulário
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password_hash'); // Ajuste no nome do campo
            $accountType = $this->request->getPost('accountType');
    
            // Criptografar a senha
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
            // Preparar dados específicos para candidato ou empresa
            if ($accountType === 'candidato') {
                $candidatoModel = new \App\Models\CandidatoModel();
                $candidatoData = [
                    'username' => $username,
                    'password_hash' => $hashedPassword,
                    'cpf_cand' => $this->request->getPost('cpf_cand'),
                    'nome_cand' => $this->request->getPost('nome_cand'),
                    'data_nasc_cand' => $this->request->getPost('data_nasc_cand'),
                    'tel_cand' => $this->request->getPost('tel_cand'),
                    'email_cand' => $this->request->getPost('email_cand'),
                ];
                $candidatoModel->insert($candidatoData);
            } elseif ($accountType === 'empresa') {
                $empresaModel = new \App\Models\EmpresaModel();
                $empresaData = [
                    'username' => $username,
                    'password_hash' => $hashedPassword,
                    'nome_emp' => $this->request->getPost('nome_emp'),
                    'cnpj_emp' => $this->request->getPost('cnpj_emp'),
                    'email_emp' => $this->request->getPost('email_emp'),
                ];
                $empresaModel->insert($empresaData);
            }
    
            // Redirecionar para a página de login após criar a conta
            return redirect()->to('/login');
        }
    
        // Carregar a view de criação de conta
        return view('criar_conta');
    }
    

    private function isLoggedIn()
    {
        return $this->session->get('logged_in');
    }
}
