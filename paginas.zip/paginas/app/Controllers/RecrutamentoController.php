<?php
namespace App\Controllers;

use App\Models\CandidatoModel;
use App\Models\EmpresaModel;
use App\Models\VagaModel;
use CodeIgniter\Controller;
use CodeIgniter\Session\Session;

class RecrutamentoController extends Controller
{
    protected $session;
    protected $helpers = ['form', 'url'];

    private $vagaModel;
    private $candidatoModel;
    private $empresaModel;

    public function __construct()
    {
        $this->vagaModel = new VagaModel();
        $this->candidatoModel = new CandidatoModel();
        $this->empresaModel = new EmpresaModel();
        $this->session = \Config\Services::session();
    }

    public function empresaDashboard()
    {
        $empresaId = $this->session->get('user_id');
        $data['vagas'] = $this->vagaModel->where('id_emp', $empresaId)->findAll();
        return view('empresa_dashboard', $data);
    }

    public function adicionarVaga()
    {
        $data = [
            'titulo_vag' => $this->request->getPost('titulo_vag'),
            'data_publi_vag' => $this->request->getPost('data_publi_vag'),
            'end_vag' => $this->request->getPost('end_vag'),
            'salario_vag' => $this->request->getPost('salario_vag'),
            'cargo_vag' => $this->request->getPost('cargo_vag'),
            'desc_vag' => $this->request->getPost('desc_vag'),
            'req_vag' => $this->request->getPost('req_vag'),
            'benef_vag' => $this->request->getPost('benef_vag'),
            'id_emp' => $this->session->get('user_id')
        ];

        $this->vagaModel->save($data);
        return redirect()->to('/empresa-dashboard');
    }
    public function atualizarVaga()
    {
        $vagaModel = new VagaModel();
        
        // Coleta os dados do formulário
        $data = [
            'titulo_vag' => $this->request->getPost('titulo_vag'),
            'data_publi_vag' => $this->request->getPost('data_publi_vag'),
            'end_vag' => $this->request->getPost('end_vag'),
            'salario_vag' => $this->request->getPost('salario_vag'),
            'cargo_vag' => $this->request->getPost('cargo_vag'),
            'desc_vag' => $this->request->getPost('desc_vag'),
            'req_vag' => $this->request->getPost('req_vag'),
            'benef_vag' => $this->request->getPost('benef_vag'),
            'id_emp' => $this->session->get('user_id') // Obtém o ID da empresa da sessão
        ];
    
        // Atualiza os dados da vaga
        $vagaModel->update($data);
    
        // Redireciona para a página de dashboard
        return redirect()->to('/empresa-dashboard');
    }
    
    

    public function removerVaga($id = null)
    {
        if ($id != null) {
            $vagaModel = new VagaModel();
            $vagaModel->removerVaga($id);
    
            // Adicionar mensagem flash de sucesso
            session()->setFlashdata('success', 'Vaga removida com sucesso.');
    
            return redirect()->to('/empresa-dashboard'); // Redirecionar para a mesma página
        } else {
            // Lógica para lidar com o ID da vaga ausente
            return redirect()->to('/erro');
        }
    }

    public function visualizarCandidato($id)
    {
        $candidato = $this->candidatoModel->find($id);
        if ($candidato) {
            return $this->response->setJSON($candidato);
        } else {
            return $this->response->setJSON(['error' => 'Candidato não encontrado']);
        }
    }

    
}
