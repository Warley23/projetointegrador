<?php
namespace App\Models;

use CodeIgniter\Model;

class CandidatoModel extends Model
{
    protected $table = 'candidatos';
    protected $primaryKey = 'id_cand';

    protected $allowedFields = [
        'username', 'password_hash', 'cpf_cand', 'nome_cand', 
        'data_nasc_cand', 'tel_cand', 'email_cand'
    ];

    public function criarCandidato($data)
    {
        return $this->insert($data);
    }

    public function verifyCredentials($username, $password)
    {
        $user = $this->where('username', $username)->first();

        if ($user && password_verify($password, $user['password_hash'])) {
            return $user;
        }

        return null;
    }
}

