<?php

// application/Models/CandidaturaModel.php

namespace App\Models;

use CodeIgniter\Model;

class CandidaturaModel extends Model
{
    protected $table = 'candidaturas';
    protected $primaryKey = 'id_candidatura';
    protected $allowedFields = ['id_cand', 'id_vag', 'data_candidatura', 'status'];
}
