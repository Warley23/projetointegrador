<?php

namespace App\Models;

use CodeIgniter\Model;

class EmpresaModel extends Model
{
    protected $table = 'empresas';
    protected $primaryKey = 'id_emp';

    protected $allowedFields = [
        'username', 'password_hash', 'nome_emp', 'cnpj_emp', 'email_emp'
    ];

    public function criarEmpresa($data)
    {
        return $this->insert($data);
    }

    public function verifyCredentials($username, $password)
    {
        $user = $this->where('username', $username)->first();

        if ($user && password_verify($password, $user['password_hash'])) {
            return $user;
        }

        return null;
    }
}

