<?php
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    // Definindo a tabela do banco de dados
    protected $table = 'candidatos';
    
    // Definindo a chave primária da tabela
    protected $primaryKey = 'id_cand';
    
    // Definindo os campos permitidos para inserção
    protected $allowedFields = ['email_cand', 'password_hash'];

    // Função para criar uma nova conta de usuário
    public function criarConta($email_cand, $password_hash)
    {
        // Criando um array de dados para inserção no banco
        $data = [
            'email_cand' => $email_cand,
            'password_hash' => password_hash($password_hash, PASSWORD_DEFAULT)
        ];

        // Inserindo os dados no banco
        return $this->insert($data);
    }

    // Função para verificar as credenciais do usuário
    public function verifyCredentials($email_cand, $password_hash)
    {
        // Buscando o usuário pelo nome de usuário
        $user = $this->where('email_cand', $email_cand)->first();

        // Verificando se o usuário foi encontrado e a senha é válida
        if ($user && password_verify($password_hash, $user['password_hash'])) {
            return $user; // Retorna o usuário encontrado
        }

        return null; // Retorna null se as credenciais não forem válidas
    }

    // Outros métodos do modelo, se necessário
}
