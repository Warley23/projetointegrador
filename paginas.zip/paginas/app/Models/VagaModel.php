<?php
namespace App\Models;

use CodeIgniter\Model;

class VagaModel extends Model
{
    protected $table = 'vagas';
    protected $primaryKey = 'id_vag';

    protected $allowedFields = [
        'titulo_vag', 'data_publi_vag', 'end_vag', 'salario_vag', 'cargo_vag', 'desc_vag', 'req_vag', 'benef_vag', 'id_emp'
    ];

    // Outros métodos...
        // Função para remover uma vaga pelo ID
        public function removerVaga($id)
        {
            return $this->delete($id); // Removendo a vaga do banco
        }
       // Função para atualizar uma vaga existente
       public function atualizarVaga($id, $dados)
       {
           return $this->update($id, $dados); // Atualizando os dados no banco
       }
}
